package problem5;

public class Parallel {

}
