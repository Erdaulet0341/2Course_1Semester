package problem5;

public class Circuit {

}
