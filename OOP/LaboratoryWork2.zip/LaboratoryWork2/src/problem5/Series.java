package problem5;

public class Series {

}
