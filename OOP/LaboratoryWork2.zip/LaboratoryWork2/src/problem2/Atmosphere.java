package problem2;

public enum Atmosphere { // base air composition
	CarbonDioxide, Nitrogen, Oxygen, Hydrogen
}
