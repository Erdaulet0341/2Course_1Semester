package problem4;

import java.util.Scanner;
import java.util.Vector;

public class Test {
	public static void main(String[] args) {
		Scanner in = new Scanner(System.in);
		Account a1 = new Account(1);
		Account a2 = new Account(2);
		Account a3 = new Account(3);
		Account c1 = new CheckingAccount(1);
		Account c2 = new CheckingAccount(2);
		Account c3 = new CheckingAccount(3);
		Account s1 = new SavingAccount(1);
		Account s2 = new SavingAccount(2);
		Account s3 = new SavingAccount(3);
		
		c3.deposit(15500);
		c3.transfer(2000,a2);
		System.out.println(a2.getBalance());
		System.out.println(c3.getBalance());
	}
}
